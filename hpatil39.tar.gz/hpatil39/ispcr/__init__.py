import subprocess

def step_one(primer_file: str, assembly_file: str) -> list[list[str]]:
    blastn_command = [
        "blastn",
        "-task", "blastn-short",
        "-query", primer_file,
        "-subject", assembly_file,
        "-outfmt", "6 std qlen"
    ]

    try:
        blast_output = subprocess.check_output(blastn_command, text=True).splitlines()

        blast_hits = [line.split('\t') for line in blast_output
                     if float(line.split('\t')[2]) >= 80 and int(line.split('\t')[3]) == int(line.split('\t')[12])]

        blast_hits.sort(key=lambda x: int(x[9]))

        formatted_hits = [str(hit) for hit in blast_hits]

        return formatted_hits

    except subprocess.CalledProcessError as e:
        print(f"Error running BLAST: {e}")
        return []





def prim_direction(sstart, send):
    return "right" if sstart < send else "left"

def calc_dist(sstart1, send1, sstart2, send2, dir1, dir2):
    if dir1 == "right" and dir2 == "left" and sstart1 < sstart2:
        return sstart2 - send1
    elif dir1 == "left" and dir2 == "right" and sstart1 > sstart2:
        return sstart1 - send2
    return None

def step_two(sorted_hits: list[str], max_amplicon_size: int) -> list[tuple[list[str]]]:
    pair = []

    for i in range(len(sorted_hits)):
        for j in range(i+1, len(sorted_hits)):
            ht1 = sorted_hits[i]
            ht2 = sorted_hits[j]

            sstart1, send1 = int(ht1[8]), int(ht1[9])
            sstart2, send2 = int(ht2[8]), int(ht2[9])

            dir1 = prim_direction(sstart1, send1)
            dir2 = prim_direction(sstart2, send2)

            if dir1 == dir2:
                continue

            dist = calc_dist(sstart1, send1, sstart2, send2, dir1, dir2)  # fixed the function name here

            if dist and 0 < dist <= max_amplicon_size:
                pair.append((ht1, ht2))

    return pair






import subprocess

def step_three(hit_pairs: list[tuple[list[str]]], assembly_file: str) -> str:
   
    bed_str = "\n".join(["{} {} {}".format(pair[0][1], int(pair[0][9]), int(pair[1][9])-1) for pair in hit_pairs])


    cmd = f"seqtk subseq {assembly_file} <(echo '{bed_str}')"
    result = subprocess.run(cmd, shell=True, executable="/bin/bash", capture_output=True, text=True)
    return result.stdout





