def needleman_wunsch(seq_a: str, seq_b: str, match: int, mismatch: int, gap: int) -> tuple[tuple[str, str], int]:
    len1, len2 = len(seq_a), len(seq_b)
    matrix = [[0 for _ in range(len2 + 1)] for _ in range(len1 + 1)]
    
    for i in range(len1 + 1):
        matrix[i][0] = gap * i
    for j in range(len2 + 1):
        matrix[0][j] = gap * j
    
    for i in range(1, len1 + 1):
        for j in range(1, len2 + 1):
            matched = matrix[i-1][j-1] + (match if seq_a[i-1] == seq_b[j-1] else mismatch)
            dele = matrix[i-1][j] + gap
            ins = matrix[i][j-1] + gap
            matrix[i][j] = max(matched, dele, ins)
    
    align_a, align_b = traceback(seq_a, seq_b, matrix, len1, len2, match, mismatch, gap)
    
    return (align_a, align_b), matrix[len1][len2]

def traceback(seq_a, seq_b, matrix, i, j, match, mismatch, gap, align_a='', align_b=''):
    if i == 0 and j == 0:
        return ''.join(reversed(align_a)), ''.join(reversed(align_b))
    
    cur_score = matrix[i][j]
    if i > 0 and j > 0 and matrix[i-1][j-1] + (match if seq_a[i-1] == seq_b[j-1] else mismatch) == cur_score:
        return traceback(seq_a, seq_b, matrix, i-1, j-1, match, mismatch, gap, align_a + seq_a[i-1], align_b + seq_b[j-1])
    elif i > 0 and matrix[i-1][j] + gap == cur_score:
        return traceback(seq_a, seq_b, matrix, i-1, j, match, mismatch, gap, align_a + seq_a[i-1], align_b + '-')
    else:  
        return traceback(seq_a, seq_b, matrix, i, j-1, match, mismatch, gap, align_a + '-', align_b + seq_b[j-1])