#!/usr/bin/env python3

import argparse
from magnumopus import ispcr, needleman_wunsch

def reverse(seq):
    complement = {'A': 'T', 'C': 'G', 'G': 'C', 'T': 'A'}
    return ''.join([complement.get(base, '') for base in reversed(seq)])

def remove_header(seq_header):
    return ''.join([line for line in seq_header.split('\n') if not line.startswith('>')])

def main(assembly1_path, assembly2_path, primers_path, max_amplicon_size, match, mismatch, gap):
    amp1 = ispcr(primers_path, assembly1_path, max_amplicon_size)
    amp2 = ispcr(primers_path, assembly2_path, max_amplicon_size)
    
    amp1_seq = remove_header(amp1)
    amp2_seq = remove_header(amp2)

    normal_align, normal_sc = needleman_wunsch(amp1_seq, amp2_seq, match, mismatch, gap)
    reverse_align, reverse_sc = needleman_wunsch(amp1_seq, reverse(amp2_seq), match, mismatch, gap)

    if normal_sc > reverse_sc:
        best_ali = normal_align
        best_sc = normal_sc
    else:
        best_ali = reverse_align
        best_sc = reverse_sc

    print(f"{best_ali[0]}\n{best_ali[1]}\n {best_sc}")

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='ISPCR on 2 files and primer')
    parser.add_argument('-1', '--assembly1', required=True, help='first assembly file')
    parser.add_argument('-2', '--assembly2', required=True, help='second assembly file')
    parser.add_argument('-p', '--primers', required=True, help='primer file')
    parser.add_argument('-m', '--max_amplicon_size', type=int, required=True, help='maximum amplicon size for isPCR')
    parser.add_argument('--match', type=int, required=True, help='match score to use in alignment')
    parser.add_argument('--mismatch', type=int, required=True, help='mismatch penalty to use in alignment')
    parser.add_argument('--gap', type=int, required=True, help='gap penalty to use in alignment')

    args = parser.parse_args()

    main(args.assembly1, args.assembly2, args.primers, args.max_amplicon_size, args.match, args.mismatch, args.gap)